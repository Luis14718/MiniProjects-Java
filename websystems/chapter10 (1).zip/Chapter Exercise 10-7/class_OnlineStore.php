<?php
class OnlineStore {
     private $DBConnect = NULL;
     private $storeID = "";
     private $inventory = array();
     private $shoppingCart = array();
}
?>
