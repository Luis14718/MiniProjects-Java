<p>Today's Date: <?php echo date('r'); ?></p>
