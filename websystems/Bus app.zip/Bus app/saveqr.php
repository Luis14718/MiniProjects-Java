<?php
session_start();
$driver= $_SESSION['Username'];
include('connect.php');

date_default_timezone_get("America/Managua");
$TIME=date("H:i:s");
$DATE=date("Y/m/d");
$sql="INSERT INTO usertp (IDemployee,Time,Date,Driver)
VALUES('$_POST[code]','$TIME','$DATE','$driver')";

if (!mysqli_query($bd,$sql))
  {
  die('Error: ' . mysqli_error());
  }
header("location: home.php");

mysqli_close($bd)
?>