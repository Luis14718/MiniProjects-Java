<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form action="saveuser.php" method="post">
FirstName:<br />
<input name="name" type="text" id="name" />
<br />
LastName:<br />
<input name="lastname" type="text" id="lastname" />
<br />
Username:<br />
<input name="username" type="text" id="username" />
<br />
Student ID:<br />
<input name="userid" type="INT" id="userid" />
<br />
Password:<br />
<input name="password" type="password" id="password" />
<br /><br />
Department:<br />
<input name="department" type="text" id="password" />
<br /><br />
<label>
<input class="site-btn" type="submit" name="" value="Save" />
</label>
</form>
</body>
</html>
