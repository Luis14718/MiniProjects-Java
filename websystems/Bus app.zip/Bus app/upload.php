<?php
$name= $FILES['fileToUpload']['name'];

?>